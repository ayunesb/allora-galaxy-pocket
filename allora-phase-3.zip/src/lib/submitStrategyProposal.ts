export async function submitStrategyProposal(strategy: any) {
  console.log("Submitting strategy to backend:", strategy);
  // Future: Save to Supabase or notify agent
}
