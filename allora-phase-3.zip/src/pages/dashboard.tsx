export default function DashboardPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">AI Strategy Dashboard</h1>
      <p>This is where your generated strategies will appear once approved.</p>
    </div>
  );
}
