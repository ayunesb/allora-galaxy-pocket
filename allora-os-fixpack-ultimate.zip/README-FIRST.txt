1. Run `npm install`
2. Run `npm run dev`
3. Visit http://localhost:5173