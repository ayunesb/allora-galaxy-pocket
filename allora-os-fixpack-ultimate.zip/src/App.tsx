// Main App entry
export default function App() { return <div>Allora OS</div>; }